# everyurban
# Implement Apache on server to run application using main domain.
# According to apache chnage config file with on 80 port
# 
# config file rename command
# mv 000-default.conf everyurban.com.conf

# enable proxy with sudo commad sudo a2enmod proxy
# enable rewrite with command line sudo a2enmod rewrite

# Restart apache services
# sudo service apache2 restart