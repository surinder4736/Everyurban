import React, { Component } from 'react';
import { Document, Page } from "react-pdf/dist/entry.webpack";
import "react-pdf/dist/Page/AnnotationLayer.css";
import PrivacyPolicyFile from '../Pdf/EveryUrban_Privacy_Policy.pdf';
export class Privacypolicy extends Component {
  constructor(props) {
    super(props);
    this.state={numPages: null,pageNumber: 1 }
}
onDocumentLoadSuccess = ({ numPages }) => {
    this.setState({ numPages });
};
componentDidMount() {
    const{dispatch}=this.props;
}

  render () {
    const {  numPages,pageNumber } = this.state;
    return (
      <div>
        <Document
            file={PrivacyPolicyFile}
            onLoadSuccess={this.onDocumentLoadSuccess}
        >
        {Array.from(new Array(numPages), (el, index) => (
        <Page key={`page_${index + 1}`} pageNumber={index + 1} width={900} />
      ))}
      </Document>
        </div>
    );
  }
}

export default (Privacypolicy);