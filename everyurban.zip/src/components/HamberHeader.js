import React, { Component } from 'react';
class Hamberg extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return ( 
            <header>
			<div className="container">
				<div className="d-flex justify-content-between align-items-center">
					<a id="hamburger" href="#"><i className="fas fa-bars"></i></a>
				</div>
			</div>
		</header>
         );
    }
}
 
export default Hamberg;