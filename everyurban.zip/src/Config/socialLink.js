export default{

    "social":[
        {
            id:1,
            name:`Facebook`
        },
        {
            id:2,
            name:`Twitter`
        },
        {
            id:3,
            name:`Linkedin`
        },
        {
            id:4,
            name:`Instagram`
        },
        {
            id:5,
            name:`Web Site`
        }
    ]
}