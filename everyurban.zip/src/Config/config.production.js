export const ENV ='production';
export const BASE_URL = `http://everyurban.com;` ///'http://45.62.223.40:8081';
export const APIURL = `${BASE_URL}/api/`;
export const hostName = `http://everyurban.com`;
export const checkAppHostName = hostName;


