export const ENV ='staging';
export const BASE_URL = 'http://122.160.166.186:7880';
export const APIURL = `${BASE_URL}/api/`;
export const hostName = `http://122.160.166.186:8083`;
export const checkAppHostName = hostName;

