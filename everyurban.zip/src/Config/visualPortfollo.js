export default{

    "portfollo":[
        {
            id:1,
            name:`Structures`
        },
        {
            id:2,
            name:`Interior`
        },
        {
            id:3,
            name:`Landscape`
        },
        {
            id:4,
            name:`Art`
        },
        {
            id:5,
            name:`Concepts`
        },
        {
            id:6,
            name:`Technical`
        },
        {
            id:7,
            name:`Floor Plans`
        },
        {
            id:8,
            name:`Other`
        }
    ],
    "postion":[
        {
            id:1,
            name: 'Intern'
        },
        {
            id:2,
            name: 'Junior Designer'
        },
        {
            id:3,
            name: 'Lead Architect'
        },
        {
            id:4,
            name: 'Principal Architect'
        }
    ]
}