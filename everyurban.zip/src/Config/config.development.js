export const ENV ='development';
export const BASE_URL='http://localhost:5000';
export const APIURL=`${BASE_URL}/api/`;
export const hostName = 'http://localhost:3000' ;
export const checkAppHostName = hostName;
